import { ICart } from "../redux/cart.model";

export interface AppState{
 cart:ICart;
}